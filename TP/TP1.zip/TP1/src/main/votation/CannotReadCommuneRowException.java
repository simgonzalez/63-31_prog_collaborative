package votation;

public class CannotReadCommuneRowException extends Exception {
  public CannotReadCommuneRowException(String message) {
    super(message);
  }
}
